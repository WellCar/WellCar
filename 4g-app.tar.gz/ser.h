#ifndef _SER_H
#define _SER_H


enum  message_type
{
    MSG_KEEP_ALIVE = 0,
    MSG_MESSAGE =1,
    MSG_OTHER =2
}MSG_TYPE;


#endif